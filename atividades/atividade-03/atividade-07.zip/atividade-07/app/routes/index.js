const express = require("express");
const router = express.Router();

router.use((req, res, next) => {
  console.log("Rota / acessada");
  next();
});

router.get('/', function(req, res, next){
  res.render('index')
})

module.exports = router;