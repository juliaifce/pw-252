var express = require('express')
var router = express.Router()

router.use((req, res, next) => {
  console.log("Rota /magic acessada");
  next();
});

router.get('/', function(req, res, next) {
  res.render('magic')
})

module.exports = router;