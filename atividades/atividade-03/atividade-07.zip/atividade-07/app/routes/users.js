const express = require("express");
const router = express.Router();

router.use((req, res, next) => {
  console.log("Rota /users acessada");
  next();
});


router.get('/', function(req, res, next) {
  var characters =[
    {
      name: 'Harry',
      role: 'Student'
    },
    {
      name: 'Dumbledore',
      role: 'Headmaster'
    },
    {
      name: 'Snape',
      role: 'Professor'
    },
    {
      name: 'Hermione',
      role: 'Student'
    }
  ];
  var subheading = "I though we should involve some magic";
  
  res.render('users', {characters: characters, subheading: subheading});
});

router.get("/", (req, res) => {
    res.render('users');
});

router.get("/signup", (req, res) => {
  res.send("<h1>Página Signup<h1>");
});

router.get("/", (req, res) => {
    res.render('signup');
});

router.get("/signin", (req, res) => {
  return res.redirect("/users/signup");
});

router.get("/", (req, res) => {
    res.render('signin');
});

router.get("/signin/:userid", (req, res) => {
  const { userid } = req.params;

  res.send(`<h1>Bem-vindo, ${userid}!<h1>`);
});


module.exports = router;