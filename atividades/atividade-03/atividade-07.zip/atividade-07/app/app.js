const express = require("express");
const path = require('path');
const app = express();
const port = 8000;

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');


app.use((req, res, next) => {
    console.log(`Acesso à rota: ${req.path}`);
    next();
});

const indexRouter = require("./routes/index")
const magicRouter = require("./routes/magic");
const aboutRouter = require("./routes/about");
const dataRouter  = require("./routes/data");
const usersRouter = require("./routes/users");
const { error } = require("console");

app.use("/", indexRouter)
app.use("/about", aboutRouter);
app.use("/data", dataRouter);
app.use("/users", usersRouter);
app.use("/magic", magicRouter);


app.get('/about', function(req, res){
  res.render('about');
})

app.get('/', function(req, res){
  res.render('index');
})

app.get('/users', function(req, res){
  res.render('users');
})

app.post('/data', function(req, res){
  res.render('Data');
})



app.use((req, res, next) => {
  const err = new Error('Página não encontrada');
  err.status = 404;
  next(err);
});

app.use((err, req, res, next) => {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: err
});
});

app.listen(8000, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});