const routes = require("express").Router();
const taskController = require("../controller/taskController");

routes.get("/", taskController.getAllTasks);
routes.post("/create", taskController.createTask);
routes.get("/search", taskController.searchTask);
routes.get("/getById/:id/:method", taskController.getById);
routes.post("/updateOne/:id", taskController.updateTask);
routes.get("/deleteOne/:id", taskController.deleteTask);
routes.get("/check/:id", taskController.taskCheck);
routes.get("/about", (req, res) => {
  res.render("about");
});
routes.get("/ajuda", (req, res) => {
  res.render("ajuda");
});
module.exports = routes;
