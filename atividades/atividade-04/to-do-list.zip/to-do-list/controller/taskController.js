const Task = require("../models/task");

let message = "";
let type = "";

const calculateCounts = (tasksList) => {
  const completedCount = tasksList.filter((task) => task.check).length;
  const pendingCount = tasksList.length - completedCount;
  const totalCount = tasksList.length;
  return { completedCount, pendingCount, totalCount };
};

const getAllTasks = async (req, res) => {
  try {
    setTimeout(() => {
      message = "";
    }, 2000);
    const tasksList = await Task.find();

    const { completedCount, pendingCount, totalCount } =
      calculateCounts(tasksList);

    return res.render("index", {
      tasksList,
      task: null,
      taskDelete: null,
      message,
      type,
      completedCount,
      pendingCount,
      totalCount,
      search: "",
    });
  } catch (err) {
    res.status(500).send({
      error: err.message,
    });
  }
};

const createTask = async (req, res) => {
  const task = req.body;

  if (!task.task) {
    message = "Insira uma tarefa antes de adicionar.";
    type = "danger";
    return res.redirect("/");
  }

  try {
    await Task.create(task);
    message = "Tarefa criada com sucesso!";
    type = "success";
    return res.redirect("/");
  } catch (err) {
    res.status(500).send({
      error: err.message,
    });
  }
};

const getById = async (req, res) => {
  try {
    const tasksList = await Task.find();
    const { completedCount, pendingCount, totalCount } =
      calculateCounts(tasksList);
    if (req.params.method == "update") {
      const task = await Task.findOne({ _id: req.params.id });
      res.render("index", {
        task,
        taskDelete: null,
        tasksList,
        message,
        type,
        completedCount,
        pendingCount,
        totalCount,
        search: "",
      });
    } else {
      const taskDelete = await Task.findOne({ _id: req.params.id });
      res.render("index", {
        task: null,
        taskDelete,
        tasksList,
        message,
        type,
        completedCount,
        pendingCount,
        totalCount,
        search: "",
      });
    }
  } catch (err) {
    res.status(500).send({
      error: err.message,
    });
  }
};

const updateTask = async (req, res) => {
  try {
    const task = req.body;
    await Task.updateOne({ _id: req.params.id }, task);
    message = "Tarefa atualizada com sucesso!";
    type = "success";
    res.redirect("/");
  } catch (err) {
    res.status(500).send({
      error: err.message,
    });
  }
};

const deleteTask = async (req, res) => {
  const id = req.params.id;
  try {
    await Task.deleteOne({ _id: req.params.id });
    message = "Tarefa excluída com sucesso!";
    type = "success";
    res.redirect("/");
  } catch (err) {
    res.status(500).send({
      error: err.message,
    });
  }
};

const taskCheck = async (req, res) => {
  try {
    const task = await Task.findOne({ _id: req.params.id });
    if (task.check) {
      task.check = false;
    } else {
      task.check = true;
    }
    await Task.updateOne({ _id: req.params.id }, task);
    res.redirect("/");
  } catch (err) {
    res.status(500).send({
      error: err.message,
    });
  }
};

const searchTask = async (req, res) => {
  try {
    const search = req.query.search || "";

    const tasksList = await Task.find({
      task: { $regex: search, $options: "i" },
    });

    const { completedCount, pendingCount, totalCount } =
      calculateCounts(tasksList);

    return res.render("index", {
      tasksList,
      task: null,
      taskDelete: null,
      message,
      type,
      completedCount,
      pendingCount,
      totalCount,
      search,
    });
  } catch (err) {
    res.status(500).send({
      error: err.message,
    });
  }
};

module.exports = {
  getAllTasks,
  createTask,
  getById,
  updateTask,
  deleteTask,
  taskCheck,
  searchTask,
};
