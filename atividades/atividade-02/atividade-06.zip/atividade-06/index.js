const express = require("express");
const app = express();
const port = 8000;

app.use((req, res, next) => {
    console.log(`Acesso à rota: ${req.path}`);
    next();
});



const aboutRouter = require("./rotas/about");
const dataRouter  = require("./rotas/data");
const usersRouter = require("./rotas/users");

app.use("/about", aboutRouter);
app.use("/data", dataRouter);
app.use("/users", usersRouter);

app.get("/", (req, res) => {
    res.send('<h1>Página Home<h1>');

});


app.use((req, res) => {
res.status(404).send(`<h1>Página não encontrada!<h1>
    <p><a href="/">Voltar para Página Home</a></p>`);
});

app.listen(8000, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});