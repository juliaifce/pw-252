const express = require("express");
const router = express.Router();

router.use((req, res, next) => {
  console.log("Rota /users acessada");
  next();
});


router.get("/", (req, res) => {
    res.send("Página Users");
});

router.get("/signup", (req, res) => {
  res.send("Página Signup");
});

router.get("/signin", (req, res) => {
  return res.redirect("/users/signup");
});

router.get("/signin/:userid", (req, res) => {
  const { userid } = req.params;

  res.send(`Bem-vindo, usuário ${userid}!`);
});


module.exports = router;