const express = require("express");
const router = express.Router();

router.use((req, res, next) => {
  console.log("Rota /users acessada");
  next();
});


router.get("/", (req, res) => {
    res.send("<h1>Página Users<h1>");
});

router.get("/signup", (req, res) => {
  res.send("<h1>Página Signup<h1>");
});

router.get("/signin", (req, res) => {
  return res.redirect("/users/signup");
});

router.get("/signin/:userid", (req, res) => {
  const { userid } = req.params;

  res.send(`<h1>Bem-vindo, ${userid}!<h1>`);
});


module.exports = router;